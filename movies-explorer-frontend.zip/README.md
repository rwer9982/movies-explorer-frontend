Ссылка на макет: https://disk.yandex.ru/d/gGfAexiLWWMyYQ 
Ссылка на сайт: https://rwer9982.nomoredomains.monster
Ссылка на сайт: https://rwer9982.nomoredomains.monster
Ссылка на backend: https://api.rwer9982.nomoredomains.monster
Pull request: https://github.com/rwer9982/movies-explorer-frontend/pull/2